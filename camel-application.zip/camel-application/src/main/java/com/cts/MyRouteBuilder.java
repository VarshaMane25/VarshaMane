package com.cts;

import org.apache.camel.builder.RouteBuilder;

public class MyRouteBuilder extends RouteBuilder{
	
	@Override
	public void configure() throws Exception{
		System.out.println("Hello from camel application");
	}

}
